﻿using System;

namespace S4HelloCSharp
{
    class HelloCSharp
    {
        static void Main()
        {
            Console.WriteLine("Hello CSharp!");
        }
    }
}
