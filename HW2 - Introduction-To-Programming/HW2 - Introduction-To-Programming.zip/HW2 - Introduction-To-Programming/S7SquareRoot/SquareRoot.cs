﻿using System;


namespace S7SquareRoot
{
    class SquareRoot
    {
        static void Main()
        {
            double a = Math.Sqrt(12345);
            Console.WriteLine(a);
        }
    }
}
