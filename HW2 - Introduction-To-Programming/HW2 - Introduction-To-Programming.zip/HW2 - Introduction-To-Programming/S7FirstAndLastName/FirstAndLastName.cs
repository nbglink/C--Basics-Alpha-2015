﻿using System;


namespace S7FirstAndLastName
{
    class FirstAndLastName
    {
        static void Main()
        {
            string firstName = "Hristo";
            string lastName = "Nestorov";
            Console.WriteLine(firstName);
            Console.WriteLine(lastName);
        }
    }
}
