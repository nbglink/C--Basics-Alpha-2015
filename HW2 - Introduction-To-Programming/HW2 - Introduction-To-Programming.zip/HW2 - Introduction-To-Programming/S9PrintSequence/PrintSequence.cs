﻿using System;


namespace S9PrintSequence
{
    class PrintSequence
    {
        static void Main()
        {
            Console.WriteLine("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9}", 2,-3,4,-5,6,-7,8,-9,10,-11);
        }
    }
}
