﻿using System;


namespace S6PrintNumbers
{
    class PrintNumbers
    {
        static void Main()
        {
            int a = 1;
            int b = 101;
            int c = 1001;

            Console.WriteLine(a);
            Console.WriteLine(b);
            Console.WriteLine(c);
        }
    }
}
