﻿using System;


namespace S5PrintMyName
{
    class PrintMyName
    {
        static void Main()
        {   
            string firstName = "Hristo";
            string lastName = "Nestrov";
            Console.WriteLine("{0} {1}", firstName,lastName);
        }
    }
}
